//子分类
$(".small-class>a").click(function() {
    $(this).siblings().removeClass("active");
    $(this).addClass('active');
});

//折叠
$(function(){
    $('.btn-show').click(function () {
        $(this).css('display','none');
        $(this).siblings('a').css('display','inline-block');
        $(this).siblings('ul.source-list').children('li:not(:first-child)').hide();
    });
    $('.btn-hide').click(function () {
        $(this).css('display','none');
        $(this).siblings('a').css('display','inline-block');
        $(this).siblings('ul.source-list').children('li').show();
    })
});

$(function () {
    $(window).resize(function () {
        MyScroll();
    });
    function MyScroll() {
        var navHeight = $(".bg-nav").height();
        var topTitle= $(".top-title").height();
        var similarH = $(".similar-h").outerHeight();
        $(".content-h1").css({"height": ($(window).height() - navHeight)});
        $(".content-h2").css({"height": ($(window).height() - navHeight)});
        $(".paper-content").css({"height": ($(window).height() - navHeight - topTitle - 70)});
        $(".right-h").css({"height": ($(window).height() - navHeight - similarH - 80)});
    }
    MyScroll();
});

var explorer =navigator.userAgent ;
//ie 
if (explorer.indexOf("MSIE") >= 0) {
	$(".modscrool").width("17px");
}
//firefox 
else if (explorer.indexOf("Firefox") >= 0) {
	$(".modscrool").width("17px");
	$(".modscrool").css({"border-left":"1px solid #eaeaea","border-right":"1px solid #eaeaea","background":"#efefef"});
}
//Chrome
else if(explorer.indexOf("Chrome") >= 0){
	$(".modscrool").width("10px");
}
//Opera
else if(explorer.indexOf("Opera") >= 0){
	$(".modscrool").width("15px");
}
//Safari
else if(explorer.indexOf("Safari") >= 0){
	$(".modscrool").width("15px");
} 
//Netscape
else if(explorer.indexOf("Netscape")>= 0) { 
	$(".modscrool").width("15px");
} 

$(function(){
	// 个人信息显示隐藏
	$(".information").mouseenter(function(){
		$(".information div").fadeIn(200);
	});
	$(".information").mouseleave(function(){
		$(".information div").fadeOut(200);
	});
	//导航切换
	$(".mr-auto>.nav-item>a").click(function(){
		$(".mr-auto>.nav-item>a").removeClass("active");
		$(this).addClass("active");
	});
	//弹窗纠错报告
	$(".jcsecces").click(function(){
		$(".fontstyle").css({"background-color":"#9e9e9e","padding":"0 2px"})
	});
	// 查重与原文标红切换状态
	$(".rights span").click(function(){
		$(this).siblings().removeClass("active");
		$(this).addClass("active");
		$(this).parents("li").find(".modify").show();
	});
	//查重
	// $(".rights span").eq(0).click(function(){
	// 	$(this).parents("li").find(".modify").show();
	// });
	//原文标红
	$(".hidemodfy").click(function(){
		$(this).parents("li").find(".modify").hide();
	});
	// //鼠标移入段落
	$(".paper-content ul li").mouseenter(function(){
		$(this).find(".mouse-show-hd").fadeIn(300);
	});
	// //鼠标移出段落
	$(".paper-content ul li").mouseleave(function(){
		var jqdspl = $(this).find(".jqjc").css("display");
		var rgdspl = $(this).find(".znjc").css("display");
		if(jqdspl == "none" && rgdspl == "none"){
			$(this).find(".mouse-show-hd").fadeOut(300);
		}
	});
	// 点击段落修改
	var dLiIndex="";
	$(".xiugai").click(function(){
		dLiIndex = $(this).parents("li").index();
		$(".paper-content ul li").eq(dLiIndex).unbind("mouseleave");
		
		$(this).hide();
		var valp = $(this).parents("li").find(".dlval").text();
		$(this).parents(".modify").find(".xiugqu").show().val(valp);
		$(this).parents(".modify").find(".xiugsh").show();
	});
	// 点击机器降重
	var jLiIndex="";
		$(".showjq").click(function(){
			jLiIndex = $(this).parents("li").index();
		});
		// 弹窗口机器降重
			$(".jqsecces").click(function(){
				var n = 0;
				var tr1=setInterval(function(){
					n+=1;
					$(".scroll-style>ul>li").eq(jLiIndex).find(".jqtiao").show().css("width",n+"%");
					$(".scroll-style>ul>li").eq(jLiIndex).find(".jqjd").text(n+"%");
					if(n>=100){
						n=100;
						clearInterval(tr1);
					}
				},45);
				$(".paper-content ul li").eq(jLiIndex).unbind("mouseleave");
				$(".paper-content ul li").eq(jLiIndex).unbind("mouseenter");
				$(".scroll-style>ul>li").eq(jLiIndex).find(".mouse-show-hd").show();
				var tr = setInterval(function(){
					$(".scroll-style>ul>li").eq(jLiIndex).find(".showjq").hide();
					$(".scroll-style>ul>li").eq(jLiIndex).find(".btnj").show();
					clearInterval(tr);
				},5000);
			});
		
		// 机器降重后内容下拉按钮
		$(".btnj").click(function(){
			$(this).toggleClass("active");
			$(this).siblings(".btnz").removeClass("active");
			$(this).parents(".modify").find(".znjc").hide();
			$(this).parents(".modify").find(".jqjc").toggle();
			$(this).siblings(".btnz").find("img").attr("src","images/icon-bottom.png");
			if($(this).is(".active")){
				$(this).find(".checkimg1").attr("src","images/icon-top1.png");
			}else{
				$(this).find(".checkimg1").attr("src","images/icon-bottom.png");				
			}
		});
	// 点击人工降重
	var rLiIndex="";
		$(".showzn").click(function(){
			rLiIndex = $(this).parents("li").index();
		});
		// 弹窗口人工降重
			$(".rgseccess").click(function(){
				var n = 0;
				var tr1=setInterval(function(){
					n+=1;
					$(".scroll-style>ul>li").eq(rLiIndex).find(".rgtiao").show().css("width",n+"%");
					$(".scroll-style>ul>li").eq(rLiIndex).find(".rgjd").text(n+"%");
					if(n>=100){
						n=100;
						clearInterval(tr1);
					}
				},45);
				$(".paper-content ul li").eq(rLiIndex).unbind("mouseleave");
				$(".paper-content ul li").eq(rLiIndex).unbind("mouseenter");
				$(".scroll-style>ul>li").eq(rLiIndex).find(".mouse-show-hd").show();
				var tr = setInterval(function(){
					$(".scroll-style>ul>li").eq(rLiIndex).find(".showzn").hide();
					$(".scroll-style>ul>li").eq(rLiIndex).find(".btnz").show();
					clearInterval(tr);
				},5000);
			});
		// 人工降重取消返回
		
		// 人工降重后内容下拉按钮
		$(".btnz").click(function(){
			$(this).toggleClass("active");
			$(this).siblings(".btnj").removeClass("active");
			$(this).parents(".modify").find(".jqjc").hide();
			$(this).parents(".modify").find(".znjc").toggle();
			$(this).siblings(".btnj").find("img").attr("src","images/icon-bottom.png");
			if($(this).is(".active")){
				$(this).find(".checkimg2").attr("src","images/icon-top1.png");
			}else{
				$(this).find(".checkimg2").attr("src","images/icon-bottom.png");
			}
		});
	//点击片段查重
	var pLiIndex ='';
	$(".pdcc").click(function(){
		pLiIndex = $(this).parents("li").index();
	});
	//弹窗片段查重
	$(".pdccscces").click(function(){
		var n = 0;
		$(".scroll-style>ul>li").eq(pLiIndex).find(".pdicon").attr("src","images/pdicon.png");
		$(".scroll-style>ul>li").eq(pLiIndex).find(".pdcc").css({"background":"white","border":"1px solid #49b97b","color":"#49b97b"});
		var tr1=setInterval(function(){
			n+=1;
			$(".scroll-style>ul>li").eq(pLiIndex).find(".pdtiao").show().css("width",n+"%");
			$(".scroll-style>ul>li").eq(pLiIndex).find(".pdjd").text(n+"%");
			if(n>=100){
				n=100;
				clearInterval(tr1);
			}
		},45);
		$(".scroll-style>ul>li").eq(pLiIndex).find(".rights").show();
	});
	//点击取消保存
	$(".qx").click(function(){
		var d1 = $(this).parents(".modify").find(".showjq").text();
		var d2 = $(this).parents(".modify").find(".showzn").text();
		if(d1 == "机器降重" && d2 =="人工降重"){
			$(".paper-content ul li").mouseleave(function(){
				var jqdspl = $(this).find(".jqjc").css("display");
				var rgdspl = $(this).find(".znjc").css("display");
				if(jqdspl == "none" && rgdspl == "none"){
					$(this).find(".mouse-show-hd").fadeOut(300);
				}
			});
		}
		$(this).parents(".modify").find(".xiugai").show();
		$(this).parents(".hidetext").find(".xiugqu").hide();
		$(this).parents(".xiugsh").hide();
	});
	//点击临时保存
	$(".bc").click(function(){
		var d1 = $(this).parents(".modify").find(".showjq").text();
		var d2 = $(this).parents(".modify").find(".showzn").text();
		if(d1 == "机器降重" && d2 =="人工降重"){
			$(".paper-content ul li").mouseleave(function(){
				var jqdspl = $(this).find(".jqjc").css("display");
				var rgdspl = $(this).find(".znjc").css("display");
				if(jqdspl == "none" && rgdspl == "none"){
					$(this).find(".mouse-show-hd").fadeOut(300);
				}
			});
		}
		$(this).parents(".modify").find(".xiugai").show();
		var newVal = $(this).parents(".hidetext").find(".xiugqu").val();
		$(this).parents("li").find(".dlval").text(newVal);
		$(this).parents(".hidetext").find(".xiugqu").hide();
		$(this).parents(".xiugsh").hide();
	});
});


