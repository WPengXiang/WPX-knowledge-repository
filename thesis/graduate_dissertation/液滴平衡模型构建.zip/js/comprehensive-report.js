
$(function(){
	// 个人信息显示隐藏
	$(".information").mouseenter(function(){
		$(".information div").fadeIn(200);
	});
	$(".information").mouseleave(function(){
		$(".information div").fadeOut(200);
	});
	//导航切换
	$(".mr-auto>.nav-item>a").click(function(){
		$(".mr-auto>.nav-item>a").removeClass("active");
		$(this).addClass("active");
	});
});

//折叠
$(function(){
    $('.detail-a').click(function () {
        $(this).parent('li').siblings().children('a').text('详情 ');
        switch($(this).is(".collapsed")) {
            case true:
                $(this).text('收起 ');
                break;
            case false:
                $(this).text('详情 ');
                break;
        }
    })
});


//进度条颜色及宽度同步
$(function () {
     $('.progress-b').each(function () {
         var b = $(this).text();
		 var numberb = b.substring(0,b.length-1);
         var progressSpan = $(this).siblings('.progress-group').children().children();
         progressSpan.css('width', b);
         if(numberb <= 40 ){
            $(this).css('color','#4ca84c');
            progressSpan.css('backgroundColor','#4ca84c');
         }else if(numberb > 40  && numberb < 70 ){
            $(this).css('color', '#ff8650');
            progressSpan.css('backgroundColor', '#ff8650');
         }else if(numberb >= 70 ){
            $(this).css('color', '#f95b5b');
            progressSpan.css('backgroundColor', '#f95b5b');
         }
    });
	$(".similar-resources").eq(0).find(".list1red").find(".progress-b").css('color','#f54141');
	$(".similar-resources").eq(0).find(".list1red").find(".progress-bar").css('backgroundColor','#f54141');
	$('.info-list li').eq(1).find(".progress-b").css('color','#f54141');
	$('.info-list li').eq(1).find(".progress-bar").css('backgroundColor','#f54141');
});

